package com.cg.ibs.cardmanagement.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

public class DebitCardBean extends CardBean {

	private BigInteger accountNumber;
	
	
	@ManyToOne @JoinColumn
	private AccountBean accountBeanObject;

	@OneToMany(mappedBy ="debitCardObject") @JoinColumn
	Set<DebitCardTransaction> debitTransaction=new HashSet<>();

	public DebitCardBean() {
		super();

	}

	public DebitCardBean(BigInteger accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}

	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "DebitCardBean [accountNumber=" + accountNumber + "]";
	}


}