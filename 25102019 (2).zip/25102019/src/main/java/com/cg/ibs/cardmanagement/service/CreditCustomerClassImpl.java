package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCustomerClassImpl extends CustomerServiceImpl  implements CreditCustomer,CreditCustomerVerification {


@Override
public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
	String creditCardNum = creditCardNumber.toString();
	Pattern pattern = Pattern.compile("[0-9]{16}");
	Matcher matcher = pattern.matcher(creditCardNum);
	if (!(matcher.find() && matcher.group().equals(creditCardNum)))
		throw new IBSException(ErrorMessages.INC_LENGTH_CARD_MESSAGE);
	boolean check1 = customerDao.verifyCreditCardNumber(creditCardNumber);
	if (!check1)
		throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
	
	return (check1);
}

@Override
public String requestCreditCardUpgrade(BigInteger creditCardNumber, int myChoice) throws IBSException {
	String Status = customerDao.getCreditCardStatus(creditCardNumber);

	if (Status.equals("Blocked")) {
		throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
	} else {

		caseIdGenOne = "RCCU";
		timestamp = LocalDateTime.now();

		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setCardNumber(creditCardNumber);
		caseIdObj.setUCI(customerDao.getCreditUci(creditCardNumber));
		if (myChoice == 1) {
			caseIdObj.setDefineServiceRequest("Gold");
			customerDao.requestCreditCardUpgrade(caseIdObj, creditCardNumber);
			return (customerReferenceID);
		} else if (myChoice == 2) {
			caseIdObj.setDefineServiceRequest("Platinum");
			customerDao.requestCreditCardUpgrade(caseIdObj, creditCardNumber);
			return (customerReferenceID);
		} else {
			return ("Choose a valid option");
		}
	}

}
@Override
public boolean verifyCreditPin(String pin, BigInteger creditCardNumber) throws IBSException {
try {
	if (pin.equals(customerDao.getCreditCardPin(creditCardNumber))) {

		return true;
	} else {
		return false;
	}}catch (IBSException e) {
		throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
}

public void resetCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
try {
	customerDao.setNewCreditPin(creditCardNumber, newPin);
	} catch (IBSException e) {
		throw new IBSException(ErrorMessages.INTERNAL_ERROR);
	}
}

	@Override
	public String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException {
		  
				caseIdGenOne = "ANCC";
				caseIdTotal = addToServiceRequestTable(caseIdGenOne);
				timestamp = LocalDateTime.now();
				caseIdObj.setCaseTimeStamp(timestamp);
				customerReferenceID = (caseIdTotal + random.nextInt(100));
				caseIdObj.setCustomerReferenceId(customerReferenceID);
				caseIdObj.setCaseIdTotal(caseIdTotal);
				caseIdObj.setStatusOfServiceRequest("Pending");
				caseIdObj.setDefineServiceRequest(newCardType);
				caseIdObj.setUCI(uci);
				try {
				customerDao.newCreditCard(caseIdObj);}
				catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
			
				return customerReferenceID;
	}

	@Override
	public String requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {
		caseIdGenOne = "RCCL";
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		timestamp = LocalDateTime.now();

		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setUCI(customerDao.getCreditUci(creditCardNumber));
		caseIdObj.setCardNumber(creditCardNumber);
		caseIdObj.setDefineServiceRequest("Blocked");
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		try {
		customerDao.requestCreditCardLost(caseIdObj, creditCardNumber);}catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		
		return (customerReferenceID);
	}

	@Override
	public String raiseCreditMismatchTicket(String transactionId) throws IBSException {
		caseIdGenOne = "RCMT";

		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setUCI(customerDao.getCMUci(transactionId));
		caseIdObj.setDefineServiceRequest("Transaction ID:" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCardNumber(customerDao.getCreditCardNumber(transactionId));
		customerDao.raiseCreditMismatchTicket(caseIdObj, transactionId);
		return (customerReferenceID);

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException {
		List<CreditCardTransaction> creditCardBeanTrns = customerDao.getCreditTrans(days, creditCardNumber);
		if (creditCardBeanTrns.isEmpty())
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		return customerDao.getCreditTrans(days, creditCardNumber);
	}

	@Override
	public String verifyCreditcardType(BigInteger creditCardNumber) throws IBSException {
		boolean check;
		try {
		 check = customerDao.verifyCreditCardNumber(creditCardNumber);}
		catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		if (check) {
			String type;
			try {
				type = customerDao.getcreditCardType(creditCardNumber);
			} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			return type;
		} else {

			throw new NullPointerException("Credit Card not found");
		}
	}

	@Override
	public boolean verifyCreditCardTransactionId(String transactionId) throws IBSException {
		boolean transactionResult = customerDao.verifyCreditTransactionId(transactionId);
		if (!transactionResult)
			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);

		return transactionResult;
	}

	@Override
	public boolean getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		boolean status = false;
		try {
		String existingStatus = customerDao.getCreditCardStatus(creditCardNumber);
		if (!existingStatus.contains("Blocked")) {
			status = true;}}
		catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
		
		return status;
	}


	@Override
	public List<CreditCardBean> viewAllCreditCards() throws IBSException{
		try {
			return customerDao.viewAllCreditCards();}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
		
		
	}

}
