package com.cg.ibs.cardmanagement.dao;


import java.math.BigInteger;

import java.util.List;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface BankDao {

	List<CaseIdBean> viewAllQueries()throws IBSException;

	List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber)throws IBSException;

	List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber)throws IBSException;

	boolean verifyCreditCardNumber(BigInteger creditCardNumber)throws IBSException;

	boolean verifyDebitCardNumber(BigInteger debitCardNumber)throws IBSException;

	boolean verifyQueryId(String queryId)throws IBSException;

	void setQueryStatus(String queryId, String newStatus)throws IBSException ;
	void actionBlockDC(String queryId, String status)throws IBSException;
	void actionBlockCC(String queryId, String status)throws IBSException;
	void actionUpgradeDC(String queryId)throws IBSException;

	void actionUpgradeCC(String queryId)throws IBSException;

	String getNewType(String queryId) throws IBSException;

	String getNewName(BigInteger uci)throws IBSException ;

	boolean actionANCC(String queryId, CreditCardBean bean1) throws IBSException;

	boolean actionANDC(String queryId, DebitCardBean bean) throws IBSException;
	BigInteger getNewUCI(String queryId) throws IBSException; 
}
