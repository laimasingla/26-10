package com.cg.ibs.cardmanagement.bean;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Accounts")



public class AccountBean {
	@Id
	@Column(length = 11,name = "account_number")
	private BigInteger accountNumber;
	@Column(nullable = false,length = 16,name = "uci")
	private BigInteger UCI;
	
	@OneToMany(mappedBy = "accountBeanObject") @JoinColumn
	Set<DebitCardBean> debitCard=new HashSet<>();
	
	@ManyToOne @JoinColumn
	private CustomerBean customerBeanObject;
	
	public BigInteger getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}
	public BigInteger getUCI() {
		return UCI;
	}
	public void setUCI(BigInteger UCI) {
		this.UCI = UCI;
	}
	public AccountBean() {
		super();
	}
	@Override
	public String toString() {
		return "AccountBean [accountNumber=" + accountNumber + ", UCI=" + UCI + "]";
	}
	public AccountBean(BigInteger accountNumber, BigInteger UCI) {
		super();
		this.accountNumber = accountNumber;
		this.UCI = UCI;
	}
	
}