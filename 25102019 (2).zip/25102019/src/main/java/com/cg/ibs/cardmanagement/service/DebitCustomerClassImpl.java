package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCustomerClassImpl  extends CustomerServiceImpl  implements DebitCustomer ,DebitCustomerVerification {


	


	


	@Override
	public boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException {
		boolean check;
		String debitCardNum = debitCardNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(debitCardNum);
		if (!(matcher.find() && matcher.group().equals(debitCardNum)))
			throw new IBSException(ErrorMessages.INC_LENGTH_CARD_MESSAGE);
		try {
	 check = customerDao.verifyDebitCardNumber(debitCardNumber);}catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		if (!check)
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		return (check);
	}

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {
		try {
			return customerDao.viewAllDebitCards();}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
			
	}

	@Override
	public String verifyDebitcardType(BigInteger debitCardNumber) throws IBSException {
		String type;
		boolean check = customerDao.verifyDebitCardNumber(debitCardNumber);
		if (check) {
			try {
			type = customerDao.getdebitCardType(debitCardNumber);}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		
			return type;
		} else {

			throw new NullPointerException("Debit card not found");
		}
	}

	@Override
	public String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice) throws IBSException {
		String status = customerDao.getDebitCardStatus(debitCardNumber);
		if (status.equals("Blocked")) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		} else {

			caseIdGenOne = "RDCU";
			timestamp = LocalDateTime.now();
			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setCardNumber(debitCardNumber);
			caseIdObj.setCustomerReferenceId(customerReferenceID);
			caseIdObj.setUCI(customerDao.getDebitUci(debitCardNumber));
			caseIdObj.setDefineServiceRequest(myChoice);
			caseIdObj.setAccountNumber(customerDao.getAccountNumber(debitCardNumber));
			try {
			customerDao.requestDebitCardUpgrade(caseIdObj, debitCardNumber);}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}

			return (customerReferenceID);
		}
	}

	@Override
	public void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException {
		try {

			customerDao.setNewDebitPin(debitCardNumber, pin);}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
		
	}

	@Override
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException {
		try {
			if (pin.equals(customerDao.getDebitCardPin(debitCardNumber)) ){

				return true;
			} else {
				return false;
			}
			}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
	}

	@Override
	public String applyNewDebitCard(BigInteger accountNumber, String newCardType) throws IBSException {
		caseIdGenOne = "ANDC";
	    
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));

		caseIdObj.setDefineServiceRequest(newCardType);
		caseIdObj.setAccountNumber(accountNumber);
		caseIdObj.setCaseIdTotal(caseIdTotal);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		BigInteger uci = customerDao.getNDCUci(accountNumber);
		caseIdObj.setUCI(uci);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		customerDao.newDebitCard(caseIdObj, accountNumber);
		return customerReferenceID;

	}

	@Override
	public String requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {
		caseIdGenOne = "RDCL";

		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));

		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(LocalDateTime.now());
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setUCI(customerDao.getDebitUci(debitCardNumber));
		caseIdObj.setCardNumber(debitCardNumber);
		caseIdObj.setDefineServiceRequest("Blocked");
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setAccountNumber(customerDao.getAccountNumber(debitCardNumber));
try {
		customerDao.requestDebitCardLost(caseIdObj, debitCardNumber);}catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		
		return (customerReferenceID);
	}

	@Override
	
		public String raiseDebitMismatchTicket(String transactionId) throws IBSException {

			caseIdGenOne = "RDMT";
			BigInteger debitCardNumber;
			debitCardNumber = customerDao.getDebitCardNumber(transactionId);
			timestamp = LocalDateTime.now();
			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setAccountNumber(customerDao.getDMAccountNumber(debitCardNumber));
			caseIdObj.setUCI(customerDao.getDMUci(transactionId));

			caseIdObj.setCardNumber(customerDao.getDebitCardNumber(transactionId));

			caseIdObj.setDefineServiceRequest("Transaction ID" + transactionId);
			caseIdObj.setCustomerReferenceId(customerReferenceID);try {
			customerDao.raiseDebitMismatchTicket(caseIdObj, transactionId);}catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
				}
			
			return (customerReferenceID);

		}
	

	@Override
	public List<DebitCardTransaction> getDebitTransactions(int days, BigInteger debitCardNumber) throws IBSException {
		List<DebitCardTransaction> debitCardBeanTrns = customerDao.getDebitTrans(days, debitCardNumber);
		if (debitCardBeanTrns.isEmpty())
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		return customerDao.getDebitTrans(days, debitCardNumber);
	}

	@Override
	public boolean checkDebitTransactionId(String transactionId) throws IBSException {
		boolean transactionResult = customerDao.verifyDebitTransactionId(transactionId);
		if (!transactionResult)
			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);

		return transactionResult;
	}

	@Override
	public boolean getDebitCardStatus(BigInteger debitCardNumber) throws IBSException {
		boolean status = false;
		try {
		String existingStatus = customerDao.getDebitCardStatus(debitCardNumber);
	
		if (!existingStatus.contains("Blocked")) {
			status = true;}	
		}catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		return status;
	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		boolean check;
		String accountNum = accountNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{11}");
		Matcher matcher = pattern.matcher(accountNum);
		if (!(matcher.find() && matcher.group().equals(accountNum)))
			throw new IBSException(ErrorMessages.INC_LENGTH_ACCOUNT_MESSAGE);
		try {
		check = customerDao.verifyAccountNumber(accountNumber);}catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
		if (!check)
			throw new IBSException(ErrorMessages.INVALID_ACCOUNT_MESSAGE);
		return (check);
	}

}
