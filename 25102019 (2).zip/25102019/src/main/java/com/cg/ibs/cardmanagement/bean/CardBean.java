package com.cg.ibs.cardmanagement.bean;

import java.math.BigInteger;
import java.time.LocalDate;

public class CardBean {
	
	
	
	private BigInteger cardNumber;
	private String cardStatus;
	private String nameOnCard;
	private String cvvNum;
	private String currentPin;
	private String cardType;
	private LocalDate dateOfExpiry;
	
	
	
	
	
	
	
	public CardBean() {
		super();
		
	}
	public CardBean(BigInteger cardNumber, String cardStatus, String nameOnCard, String cvvNum, String currentPin,
			String cardType, LocalDate dateOfExpiry) {
		super();
		this.cardNumber = cardNumber;
		this.cardStatus = cardStatus;
		this.nameOnCard = nameOnCard;
		this.cvvNum = cvvNum;
		this.currentPin = currentPin;
		this.cardType = cardType;
		this.dateOfExpiry = dateOfExpiry;
	}
	@Override
	public String toString() {
		return "CardBean [cardNumber=" + cardNumber + ", cardStatus=" + cardStatus + ", nameOnCard=" + nameOnCard
				+ ", cvvNum=" + cvvNum + ", currentPin=" + currentPin + ", cardType=" + cardType + ", dateOfExpiry="
				+ dateOfExpiry + "]";
	}
	public BigInteger getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(BigInteger cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public String getNameOnCard() {
		return nameOnCard;
	}
	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}
	public String getCvvNum() {
		return cvvNum;
	}
	public void setCvvNum(String cvvNum) {
		this.cvvNum = cvvNum;
	}
	public String getCurrentPin() {
		return currentPin;
	}
	public void setCurrentPin(String currentPin) {
		this.currentPin = currentPin;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	
	
	
	
	
	
}
