package com.cg.ibs.cardmanagement.bean;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "Credit_Card")
public class CreditCardBean extends CardBean {

	@Id

	@Column(nullable = false, length = 16, name = "UCI")
	private BigInteger UCI;

	@Column(nullable = false, length = 3, name = "credit_score")
	private int creditScore;
	@Column(nullable = false, name = "credit_limit")
	private BigDecimal creditLimit;
	@Column(nullable = false, name = "customer_income")
	private double income;

	@ManyToOne
	@JoinColumn
	private CustomerBean custBeanObject;

	@OneToMany(mappedBy = "creditBeanObject")
	@JoinColumn
	Set<CreditCardTransaction> creditTransaction = new HashSet<>();

	public CreditCardBean() {
		super();

	}

	public CreditCardBean(BigInteger uCI2, String creditCardType, int creditScore, BigDecimal creditLimit,
			double income) {
		super();

		this.UCI = uCI2;

		this.creditScore = creditScore;
		this.creditLimit = creditLimit;
		this.income = income;
	}

	public BigInteger getUCI() {
		return UCI;
	}

	public void setUCI(BigInteger UCI) {
		this.UCI = UCI;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	@Override
	public String toString() {
		return "CreditCardBean [ UCI=" + UCI + ", creditCardType=" + creditScore + ", creditLimit=" + creditLimit
				+ ", income=" + income + "]";
	}

}
